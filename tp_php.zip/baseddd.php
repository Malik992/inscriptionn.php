
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>employes</title>

</head>
<body>
<fieldset>
    <legend>inscription des employers</legend>

<form action="conection.php" method="post">
    <table>
    <tr>
        <td>matricule</td>
        <td><input type="text" name="matricule"></td>
    </tr>
    <tr>
        <td>nom complet</td>
        <td><input type="text" name="nomcom"></td>
    </tr>
    <tr>
        <td>tel</td>
        <td><input type="number" name="tel"></td>
    </tr>
   <tr>
       <td>email</td>
       <td><input type="email" name="email"></td>
   </tr>
    <tr>
        <td>salaire</td>
        <td> <input type="number" name="salaire"></td>
    </tr>
    <tr>
        <td>date de naissance</td>
        <td><input type="text" name="datenais"></td>
    </tr>
    <tr>
        <td>id service</td>
        <td><input type="text" name="idserv"></td>
    </tr>
    <tr>
        <td></td>
        <td>
        <input  type="submit" name="submit" value="enregistrer">
        </td>
    </tr>



    </table>
         
  

</form>
</fieldset>
   

    <table border="solid 2px">

 <tr id="tr1">
     <style>
         table{
            border-color: gray;
            border-collapse: collapse;
         }
    
     #tr1 td{
         width: 200px;
     }

     
     </style>
     <td>matricule</td>
<td>nom complet</td>
<td>tel</td>
<td>email</td>
<td>salaire</td>
<td>date de naissance</td>
<td>id service</td>


</tr>


    
    <?php   
   try{
    $bdd = new PDO('mysql:host=localhost;dbname=phplogin;charset=utf8', 'root', 'malik92');
   }  
   catch(Exception $e)
      {
        die('Erreur : '.$e->getMessage());
      }

      $sql="matricule,nom complet,tel,email,salaire,date,id service,matricule,nomcom,tel,email,salaire,datenais,idserv";
      
    
      
 

$reponse = $bdd->query('SELECT * FROM employes');  

while ($donnees = $reponse->fetch())
{
    ?>
    <tr>
    <td> <?php echo $donnees['matricule']; ?></td>
    <td> <?php echo $donnees['nomcom']; ?></td>
   
    <td> <?php echo $donnees['tel']; ?></td>
    <td> <?php echo $donnees['email']; ?></td>
    <td> <?php echo $donnees['salaire']; ?></td>
    <td> <?php echo $donnees['datenais']; ?></td>
    <td> <?php echo $donnees['idserv']; ?></td>
    
   
</tr>
<?php
}

$reponse->closeCursor(); 
    
?>
</table>
</body>
</html>