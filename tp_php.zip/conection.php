<?php
$matricule=filter_input(INPUT_POST,'matricule');
$nomcom=filter_input(INPUT_POST,'nomcom');
$tel=filter_input(INPUT_POST,'tel');
$email=filter_input(INPUT_POST,'email');
$salaire=filter_input(INPUT_POST,'salaire');
$datenais=filter_input(INPUT_POST,'datenais');
$idserv=filter_input(INPUT_POST,'idserv');
try{
    include 'baseddd.php';
    extract($_POST);
    $matricule=filter_input(INPUT_POST,'matricule');
    $sql="select* from employes where matricule='".$matricule."'";
    $reponse=$bdd->query($sql);
    if($donnees=$reponse->fetch())
    {
    echo'un employer de ce matricule existe déjà';
    echo'<a href="baseddd.php">RETOUR</a>';
    
    
    
    }
    else
    {

        $bdd = new PDO('mysql:host=localhost;dbname=phplogin', 'root', 'malik92');
        $sql = "INSERT INTO employes(matricule,nomcom,tel,email,salaire,datenais,idserv)
        values('$matricule','$nomcom', '$tel', '$email','$salaire','$datenais','$idserv')";
        
        if($bdd->query($sql))
        {
        
            echo"merci <br>";
        }
        else{
            echo"error <br>";
        }
        
    }
}
catch(Exception $e){
    echo $e->getMessage();
}


?>
 