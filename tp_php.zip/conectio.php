<?php
try{
include 'basedd.php';
extract($_POST);
$nom=filter_input(INPUT_POST,'nom');
$sql="select* from service where nom='".$nom."'";
$reponse=$bdd->query($sql);
if($donnees=$reponse->fetch())
{
echo'un service de ce nom existe déjà';
echo'<a href="basedd.php">RETOUR</a>';



}
else
{


    $nom=filter_input(INPUT_POST,'nom');
    $localite=filter_input(INPUT_POST,'localite');
    
    
    if(!empty($nom))
    {
        if(!empty($localite))
        {
            $bdd = new PDO('mysql:host=localhost;dbname=phplogin', 'root', 'malik92');
        
            $sql="INSERT INTO service(nom,localite) VALUES ('$nom','$localite')";
            if($bdd->query($sql))
            {
    
                echo"merci <br>";
            }
            else{
                echo"error <br>";
            }
        
        }
        else
        {
            echo"la localite ne doit pas etre vide";
            die();
        }
    
    }
    else
    {
        echo"le nom ne doit pas etre vide";
        die();
    }
    }
}
catch(Exception $e){
    echo $e->getMessage();
}


?>