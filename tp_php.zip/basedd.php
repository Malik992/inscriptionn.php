
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>service</title>
</head>
<body>
           
<fieldset>
    <table>
    <legend><u>Bienvenue sur votre service</u></legend>
        
            <form action="conectio.php" method="POST">
                <tr>
                    <td>Nom :</td>
                    <td><input type="text" name="nom" placeholder="Entrer votre nom"></td>
                </tr>
                <tr>
                    <td>Localité  :</td>
                    <td><input type="text" name="localite" placeholder="Entrer votre localité"></td>
                </tr>
              
                <tr>
                    <td></td>
                    <td><input type="submit" value="connexion" name="connexion"></td>
                </tr>
                

        </table>

    </fieldset>

</form>
</fieldset>
   

    <table border="solid 2px">

 <tr id="tr1">
     <style>
         table{
            border-color: gray;
            border-collapse: collapse;
         }
    
     #tr1 td{
         width: 200px;
     }

     
     </style>
<td>id service</td>
<td>nom</td>
<td>localite</td>
</tr>


    
    <?php   
   try{
    $bdd = new PDO('mysql:host=localhost;dbname=phplogin;charset=utf8', 'root', 'malik92');
   }  
   catch(Exception $e)
      {
        die('Erreur : '.$e->getMessage());
      }

      $sql="id service,nom,localite,id,nom,localite";
      
    
      
 

$reponse = $bdd->query('SELECT * FROM service');  

while ($donnees = $reponse->fetch())
{
    ?>
    <tr>
    <td> <?php echo $donnees['id']; ?></td>
    <td> <?php echo $donnees['nom']; ?></td>
    <td> <?php echo $donnees['localite']; ?></td>
</tr>
<?php
}

$reponse->closeCursor(); 
    
?>
</table>
    
</body>
</html>